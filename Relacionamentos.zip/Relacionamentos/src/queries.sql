--insert into cliente (id, nome, email) values (1, 'Jos�', 'jose@email.com');
--insert into cliente (id, nome, email) values (2, 'Maria', 'maria@email.com');
--
--insert into produto (id, nome, valor) values (1, 'Placa-m�e', 200.0);
--insert into produto (id, nome, valor) values (2, 'Placa de video', 800.0);
--insert into produto (id, nome, valor) values (3, 'HD', 300.0);


select * from produto;