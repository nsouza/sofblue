package br.com.softblue.javaee.model;

import java.io.Serializable;
import java.lang.Integer;
import javax.persistence.*;
import javax.persistence.Enumerated;

/**
 * Entity implementation class for Entity: Pagamento
 *
 */
@Entity
public class Pagamento implements Serializable {
	public enum TipoPagamento {
		CARTAO_CREDITO,
		BOLETO
	}

	   
	@Id
	@GeneratedValue
	private Integer id;	
	
	@Enumerated(EnumType.STRING)
	@Column(name = "tipo_pgto", length = 20, nullable = false)
	private TipoPagamento tipoPagto;
	
	@OneToOne(mappedBy = "pagamento")
	private Pedido pedido;

	  
	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public TipoPagamento getTipoPagto() {
		return tipoPagto;
	}

	public void setTipoPagto(TipoPagamento tipoPagto) {
		this.tipoPagto = tipoPagto;
	}
	
	public Pedido getPedido() {
		return pedido;
	}

	public void setPedido(Pedido pedido) {
		this.pedido = pedido;
	}

	@Override
	public String toString() {
		return "Pagamento [id=" + id + ", tipoPagto=" + tipoPagto + "]";
	} 
	
		
}
