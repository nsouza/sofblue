package br.com.softblue.javae.ejb;

import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import br.com.softblue.javaee.model.Cliente;

@Stateless
public class ClienteBean {
	
	@PersistenceContext
	private EntityManager em;
	
	public List<Cliente> listar() {
		return em.createQuery("SELECT C FROM cliente c", Cliente.class).getResultList();
	}
	
	
}
