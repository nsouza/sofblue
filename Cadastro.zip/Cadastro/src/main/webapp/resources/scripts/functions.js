function mostrarAviso() {
	alart ("Voce clicou no botão");
}