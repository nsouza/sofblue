function validacaoCampo() {
						
			if(document.getElementById("fcadastro:curiosidade").value == ""){
				alert('Por favor, preencha o campo curiosidade');
				document.getElementById("fcadastro:curiosidade").focus();
				return false
			}
			
			alert("O campo curiosidade preenchio com sucesso!!!")
}

function formatarData(campoData) {
    var data = campoData.value;
    if (data.length === 2) {
	    data += '/';
        campoData.value = data;
    }
    if (data.length === 5) {
	    data += '/';
        campoData.value = data;
    }   
}