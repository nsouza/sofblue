package br.com.pizzarialastapas.model;

import java.io.Serializable;
import java.lang.Double;
import java.lang.Integer;
import java.util.Date;
import javax.persistence.*;

/**
 * Entity implementation class for Entity: Preco
 *
 */
@Entity
public class Preco implements Serializable {

	   
	@Id
	private Integer id;
	private Double valor;
	private Date date;
	private static final long serialVersionUID = 1L;

	public Preco() {
		super();
	}   
	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}   
	public Double getValor() {
		return this.valor;
	}

	public void setValor(Double valor) {
		this.valor = valor;
	}   
	public Date getDate() {
		return this.date;
	}

	public void setDate(Date date) {
		this.date = date;
	}
   
}
