package br.com.pizzarialastapas.model;

import java.io.Serializable;
import java.lang.Integer;
import java.lang.String;
import javax.persistence.*;

/**
 * Entity implementation class for Entity: TipoPizza
 *
 */
@Entity
public class TipoPizza implements Serializable {

	   
	@Id
	private Integer id;
	private String nome;
	private Integer preco;
	private String historico;
	private String curiosidade;
	private static final long serialVersionUID = 1L;

	public TipoPizza() {
		super();
	}   
	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}   
	public String getNome() {
		return this.nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}   
	public Integer getPreco() {
		return this.preco;
	}

	public void setPreco(Integer preco) {
		this.preco = preco;
	}   
	public String getHistorico() {
		return this.historico;
	}

	public void setHistorico(String historico) {
		this.historico = historico;
	}   
	public String getCuriosidade() {
		return this.curiosidade;
	}

	public void setCuriosidade(String curiosidade) {
		this.curiosidade = curiosidade;
	}
   
}
