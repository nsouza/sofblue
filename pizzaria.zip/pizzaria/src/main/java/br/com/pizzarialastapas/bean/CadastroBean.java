package br.com.pizzarialastapas.bean;

import java.io.Serializable;
import java.util.Date;

import javax.enterprise.context.RequestScoped;
import javax.inject.Named;

/**
 * Session Bean implementation class Cadastro
 */
@Named("cadastro")
@RequestScoped
public class CadastroBean implements Serializable{

	private String nome;
	private String componentes;
	private String curiosidades;
	private String preco;
	private String ativo;
	private Boolean validado;
	private Date dataCadastro;
	
	
	   
    public CadastroBean() {
        // TODO Auto-generated constructor stub
    }


	public String getNome() {
		return nome;
	}


	public void setNome(String nome) {
		this.nome = nome;
	}


	public String getComponentes() {
		return componentes;
	}


	public void setComponentes(String componentes) {
		this.componentes = componentes;
	}


	public String getCuriosidades() {
		return curiosidades;
	}


	public void setCuriosidades(String curiosidades) {
		this.curiosidades = curiosidades;
	}


	public String getPreco() {
		return preco;
	}


	public void setPreco(String preco) {
		this.preco = preco;
	}


	public String getAtivo() {
		return ativo;
	}


	public void setAtivo(String ativo) {
		this.ativo = ativo;
	}


	public Boolean getValidado() {
		return validado;
	}


	public void setValidado(Boolean validado) {
		this.validado = validado;
	}
	
	public Date getDataCadastro() {
		return dataCadastro;
	}
	
	public void setDataCadastro(Date dataCadastro) {
		this.dataCadastro = dataCadastro;
	}

	
    
}
