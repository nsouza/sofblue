package br.com.pizzarialastapas.bean;

import javax.ejb.Local;

@Local
public interface CadastroLocal {

}
